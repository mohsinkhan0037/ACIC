
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.graphics import Color, RoundedRectangle, Rectangle

GREEN = (0.145, 0.302, 0.231, 1)
GREEN_DARK = (0.105, 0.235, 0.176, 1)
SAGE = (0.91, 0.95, 0.91, 1)
BG = (0.965, 0.973, 0.953, 1)
WHITE = (1, 1, 1, 1)
TEXT = (0.16, 0.20, 0.17, 1)
MUTED = (0.40, 0.45, 0.41, 1)
RED = (0.72, 0.22, 0.22, 1)

FREQUENCIES = {
    "Annually": 1,
    "Half-yearly": 2,
    "Quarterly": 4,
    "Monthly": 12,
}


def money(value):
    return f"₹{value:,.2f}"


def calculate(deposit, deposit_count, deposit_frequency,
              holding_count, holding_frequency, annual_rate,
              compounding_frequency):

    dep_per_year = FREQUENCIES[deposit_frequency]
    hold_per_year = FREQUENCIES[holding_frequency]
    compounds_per_year = FREQUENCIES[compounding_frequency]

    total_months = holding_count * 12 // hold_per_year
    deposit_months = deposit_count * 12 // dep_per_year

    if total_months <= 0:
        raise ValueError("Holding period must be greater than zero.")

    if deposit_months <= 0:
        raise ValueError("Deposit period must be greater than zero.")

    if deposit_months > total_months:
        raise ValueError("Deposit period cannot exceed holding period.")

    annual_decimal = annual_rate / 100
    periodic_rate = annual_decimal / compounds_per_year

    monthly_rate = (
        (1 + periodic_rate) ** (compounds_per_year / 12) - 1
    )

    deposit_interval = 12 // dep_per_year
    row_interval = 12 // hold_per_year

    balance = 0.0
    total_deposit = 0.0
    total_interest = 0.0

    rows = []
    period_interest = 0.0
    period_deposit = 0.0

    balance += deposit
    total_deposit += deposit
    period_deposit += deposit

    for month in range(1, total_months + 1):

        interest = balance * monthly_rate
        balance += interest

        total_interest += interest
        period_interest += interest

        if (
            month < total_months
            and month < deposit_months
            and month % deposit_interval == 0
        ):
            balance += deposit
            total_deposit += deposit
            period_deposit += deposit

        if month % row_interval == 0:

            rows.append({
                "year": len(rows) + 1,
                "deposit": period_deposit,
                "interest": period_interest,
                "cumulative": total_interest,
                "return": balance,
            })

            period_interest = 0.0
            period_deposit = 0.0

    return total_deposit, total_interest, balance, rows


class Panel(BoxLayout):

    def __init__(self, **kwargs):
        super().__init__(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(8),
            **kwargs
        )

        with self.canvas.before:
            Color(*WHITE)
            self.bg_rect = RoundedRectangle(radius=[dp(10)])

        self.bind(pos=self._update, size=self._update)

    def _update(self, *_):
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size


class CalculatorApp(App):

    title = "Compound Interest Calculator"

    def build(self):

        Window.clearcolor = BG

        root = BoxLayout(
            orientation="vertical",
            spacing=0
        )

        header = BoxLayout(
            size_hint_y=None,
            height=dp(54),
            padding=[dp(14), 0]
        )

        with header.canvas.before:
            Color(*GREEN)
            self.header_rect = Rectangle(
                pos=header.pos,
                size=header.size
            )

        header.bind(
            pos=lambda w, *_: setattr(
                self.header_rect, "pos", w.pos
            ),
            size=lambda w, *_: setattr(
                self.header_rect, "size", w.size
            )
        )

        header.add_widget(
            Label(
                text="Compound Interest Calculator",
                bold=True,
                color=WHITE,
                font_size="18sp",
                halign="left"
            )
        )

        root.add_widget(header)

        scroll = ScrollView(do_scroll_x=False)

        body = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(10),
            size_hint_y=None
        )

        body.bind(minimum_height=body.setter("height"))

        scroll.add_widget(body)
        root.add_widget(scroll)

        form = Panel(size_hint_y=None)
        form.bind(minimum_height=form.setter("height"))

        form.add_widget(
            self.section_label("Investment inputs")
        )

        self.deposit = self.add_input(
            form, "Deposit amount (₹)", "0"
        )

        self.deposit_frequency = self.add_spinner(
            form, "Deposit frequency", "Annually"
        )

        self.deposit_period = self.add_input(
            form, "Deposit period", "0"
        )

        self.holding_frequency = self.add_spinner(
            form, "Holding period frequency", "Annually"
        )

        self.holding_period = self.add_input(
            form, "Holding period", "0"
        )

        self.rate = self.add_input(
            form, "Annual interest rate (%)", "0"
        )

        self.compounding = self.add_spinner(
            form, "Compounding frequency", "Annually"
        )

        body.add_widget(form)

        actions = BoxLayout(
            size_hint_y=None,
            height=dp(46),
            spacing=dp(8)
        )

        actions.add_widget(
            self.make_button(
                "RESET", GREEN_DARK, self.reset_fields
            )
        )

        actions.add_widget(
            self.make_button(
                "CALCULATE", GREEN, self.run_calculation
            )
        )

        body.add_widget(actions)

        self.result_panel = Panel(
            size_hint_y=None,
            height=dp(140)
        )

        self.result_panel.add_widget(
            self.section_label("Results")
        )

        self.total_principal = self.result_label(
            "Total invested: ₹0.00"
        )

        self.interest_amount = self.result_label(
            "Interest amount: ₹0.00", RED
        )

        self.maturity_value = self.result_label(
            "Maturity value: ₹0.00", GREEN_DARK, True
        )

        for item in (
            self.total_principal,
            self.interest_amount,
            self.maturity_value
        ):
            self.result_panel.add_widget(item)

        body.add_widget(self.result_panel)

        table_button = self.make_button(
            "INTEREST TABLE",
            GREEN_DARK,
            self.show_table
        )

        table_button.size_hint_y = None
        table_button.height = dp(44)

        body.add_widget(table_button)

        self.table_panel = Panel(
            size_hint_y=None,
            height=dp(0),
            opacity=0
        )

        self.table_panel.add_widget(
            self.section_label("Interest table")
        )

        self.table_grid = GridLayout(
            cols=4,
            size_hint_y=None,
            spacing=dp(5),
            row_default_height=dp(34),
            row_force_default=True,
            cols_minimum={
                0: dp(30),
                1: dp(85),
                2: dp(95),
                3: dp(105),
            }
        )

        self.table_grid.bind(
            minimum_height=self.table_grid.setter("height")
        )

        self.table_panel.add_widget(self.table_grid)
        body.add_widget(self.table_panel)

        self.last_result = None

        self.run_calculation()

        return root

    def section_label(self, text):

        return Label(
            text=text,
            size_hint_y=None,
            height=dp(26),
            color=GREEN_DARK,
            bold=True,
            font_size="15sp",
            halign="left"
        )

    def add_input(self, parent, label, default):

        row = BoxLayout(
            size_hint_y=None,
            height=dp(42),
            spacing=dp(8)
        )

        row.add_widget(
            Label(
                text=label,
                color=TEXT,
                halign="left",
                size_hint_x=0.58,
                font_size="13sp"
            )
        )

        field = TextInput(
            text=default,
            multiline=False,
            input_filter="float",
            size_hint_x=0.42,
            font_size="15sp",
            background_normal="",
            background_active="",
            background_color=BG,
            foreground_color=TEXT,
            cursor_color=GREEN,
            padding=[dp(8), dp(9)]
        )

        row.add_widget(field)
        parent.add_widget(row)

        return field

    def add_spinner(self, parent, label, default):

        row = BoxLayout(
            size_hint_y=None,
            height=dp(42),
            spacing=dp(8)
        )

        row.add_widget(
            Label(
                text=label,
                color=TEXT,
                halign="left",
                size_hint_x=0.58,
                font_size="13sp"
            )
        )

        spinner = Spinner(
            text=default,
            values=list(FREQUENCIES.keys()),
            size_hint_x=0.42,
            font_size="13sp",
            background_normal="",
            background_color=SAGE,
            color=GREEN_DARK
        )

        row.add_widget(spinner)
        parent.add_widget(row)

        return spinner

    def result_label(self, text, color=TEXT, bold=False):

        return Label(
            text=text,
            size_hint_y=None,
            height=dp(25),
            color=color,
            bold=bold,
            font_size="14sp",
            halign="left"
        )

    def make_button(self, text, color, callback):

        button = Button(
            text=text,
            background_normal="",
            background_color=color,
            color=WHITE,
            bold=True,
            font_size="14sp"
        )

        button.bind(on_release=callback)

        return button

    def run_calculation(self, *_):

        try:

            amount = float(self.deposit.text)
            deposits = int(float(self.deposit_period.text))
            holding = int(float(self.holding_period.text))
            rate = float(self.rate.text)

            if amount <= 0:
                raise ValueError("Deposit must be greater than zero.")

            if deposits <= 0 or holding <= 0:
                raise ValueError("Periods must be greater than zero.")

            if rate < 0:
                raise ValueError("Interest rate cannot be negative.")

            principal, interest, maturity, rows = calculate(
                amount,
                deposits,
                self.deposit_frequency.text,
                holding,
                self.holding_frequency.text,
                rate,
                self.compounding.text
            )

            self.last_result = (
                principal,
                interest,
                maturity,
                rows
            )

            self.total_principal.text = (
                f"Total invested: {money(principal)}"
            )

            self.interest_amount.text = (
                f"Interest amount: {money(interest)}"
            )

            self.maturity_value.text = (
                f"Maturity value: {money(maturity)}"
            )

            self.populate_table(rows)

        except (ValueError, OverflowError, KeyError) as exc:

            self.last_result = None

            self.total_principal.text = "Please check your inputs."

            self.interest_amount.text = str(exc)

            self.maturity_value.text = ""

            self.table_grid.clear_widgets()

    def populate_table(self, rows):

        self.table_grid.clear_widgets()

        headers = [
            "Period",
            "Deposit",
            "Interest",
            "Return"
        ]

        for heading in headers:

            self.table_grid.add_widget(
                Label(
                    text=heading,
                    color=GREEN_DARK,
                    bold=True,
                    font_size="11sp"
                )
            )

        for row in rows:

            values = [
                str(row["year"]),
                f'{row["deposit"]:,.2f}',
                f'{row["interest"]:,.2f}',
                f'{row["return"]:,.2f}'
            ]

            for value in values:

                self.table_grid.add_widget(
                    Label(
                        text=value,
                        color=TEXT,
                        font_size="12sp"
                    )
                )

    def show_table(self, *_):

        if not self.last_result:
            self.run_calculation()

        if self.last_result:

            row_count = len(self.last_result[3]) + 1

            self.table_panel.height = dp(
                40 + 39 * row_count
            )

            self.table_panel.opacity = 1

        else:

            self.table_panel.height = dp(0)
            self.table_panel.opacity = 0

    def reset_fields(self, *_):

        self.deposit.text = "0"
        self.deposit_period.text = "0"
        self.holding_period.text = "0"
        self.rate.text = "0"

        self.deposit_frequency.text = "Annually"
        self.holding_frequency.text = "Annually"
        self.compounding.text = "Annually"

        self.table_panel.height = dp(0)
        self.table_panel.opacity = 0

        self.run_calculation()


if __name__ == "__main__":
    CalculatorApp().run()
    